$(function(){
	var $target = $('#drop-zone');
	function dropZone($target, onDrop) {
		$target.
			bind('dragover', function(){
				$target.addClass( 'drag-over' );
				return false;
			}).
			bind("dragend", function () {
				$target.removeClass( 'drag-over' );
				return false;
			}).
			bind("dragleave", function () {
				$target.removeClass( 'drag-over' );
				return false;
			}).
			bind("drop", function(event) {
				var file = event.originalEvent.dataTransfer.files[0];

				event.stopPropagation();
				event.preventDefault();

				$target.removeClass( 'drag-over' );

				var droppedImage = new Image();
				var fileReader = new FileReader();

				fileReader.onload = function (event) {
					droppedImage.src = event.target.result;
					$target.html(droppedImage);
				};

				fileReader.readAsDataURL(file);

				onDrop(file);
			});
	}

	dropZone($target, function (file) {
	    resemble(file).onComplete(function (data) {
			$('#image-data').show();
			$('#red').css('width',data.red+'%');
			$('#green').css('width',data.green+'%');
			$('#blue').css('width',data.blue+'%');
			$('#alpha').css('width',data.alpha+'%');
			$('#brightness').css('width',data.brightness+'%');
			$('#white').css('width',data.white+'%');
			$('#black').css('width',data.black+'%');
		});
	});

	function antialiasing(){
	    antialisingFlag = false;
	    processImages(1);
	}

	function ignoreNothing() {
	    ignoreNothingFlag = false;
	    processImages(1);
	}

	var globalImage = new Image();
	var antialisingFlag = false;
	var ignoreNothingFlag = false;
	function onComplete(data) {
	    if (antialisingFlag) {
	        antialiasing();
	        return false;
	    }
	    if (ignoreNothingFlag) {
	        ignoreNothing();
	        return false;
	    }
		var time = Date.now();
		var diffImage = new Image();
		diffImage.src = data.getImageDataUrl();
		globalImage = diffImage;
		$('#image-diff' + globalCount).html('');
		$('#image-diff' + globalCount).html(globalImage);
	
		$(diffImage).click(function(){
			window.open(diffImage.src, '_blank');
	    });

		$('.buttons').show();

		if(data.misMatchPercentage == 0){
		    $('#thesame' + globalCount).show();
		    $('#diff-results' + globalCount).hide();
		} else {
		    $('#mismatch' + globalCount).text(data.misMatchPercentage);
			if(!data.isSameDimensions){
			    $('#differentdimensions' + globalCount).show();
			} else {
			    $('#differentdimensions' + globalCount).hide();
			}
			$('#diff-results' + globalCount).show();
			$('#thesame' + globalCount).hide();
		}

		if (globalCount != null) {
		    globalCount++;
		    processImages(globalCount);
		}
	}

	var buttons = $('.buttons button');

	buttons.click(function () {
		var $this = $(this);
		$this.parent('.buttons').find('button').removeClass('active');
		$this.addClass('active');

		if ($this.is('#raw')) {
		    ignoreNothingFlag = true;
		    globalCount = 1;
		    resembleControl.ignoreNothing();
		}
		else
		if($this.is('#less')){
			resembleControl.ignoreLess();
		}
		if($this.is('#colors')){
			resembleControl.ignoreColors();
		}
		else
		    if ($this.is('#antialising')) {
		    antialisingFlag = true;
		    globalCount = 1;
		    resembleControl.ignoreAntialiasing();
		}
		else
		if($this.is('#same-size')){
			resembleControl.scaleToSameSize();
		}
		else
		if($this.is('#original-size')){
			resembleControl.useOriginalSize();
		}
		else
		if($this.is('#pink')){
			resemble.outputSettings({
				errorColor: {
					red: 255,
					green: 0,
					blue: 255
				}
			});
			resembleControl.repaint();
		}
		else
		if($this.is('#yellow')){
			resemble.outputSettings({
				errorColor: {
					red: 255,
					green: 255,
					blue: 0
				}
			});
			resembleControl.repaint();
		}
		else
		if($this.is('#flat')){
			resemble.outputSettings({
				errorType: 'flat'
			});
			resembleControl.repaint();
		}
		else
		if($this.is('#movement')){
			resemble.outputSettings({
				errorType: 'movement'
			});
			resembleControl.repaint();
		}
		else
		if($this.is('#flatDifferenceIntensity')){
			resemble.outputSettings({
				errorType: 'flatDifferenceIntensity'
			});
			resembleControl.repaint();
		}
		else
		if($this.is('#movementDifferenceIntensity')){
			resemble.outputSettings({
				errorType: 'movementDifferenceIntensity'
			});
			resembleControl.repaint();
		}
		else
		if($this.is('#opaque')){
			resemble.outputSettings({
				transparency: 1
			});
			resembleControl.repaint();
		}
		else
		if($this.is('#transparent')){
			resemble.outputSettings({
				transparency: 0.3
			});
			resembleControl.repaint();
		}
	});

	$('#reset-images').click(function () {
	    location.reload();
	});

	var totalCountFromTxtBox = "";
	var arrNumbers = [];
	$('#example-images').click(function (e) {
	    if ($('#imageNos').val() == "" || $('#ddlCountry').find(':selected').text() == "--Select--") {
            alert('Please complete the required feilds!')
	        return false;
	    }

	    arrNumbers = $('#imageNos').val().split(',');
	    jQuery.each(arrNumbers, function(index,value){
	        arrNumbers[index] = value.substring(10);
        });

        totalCountFromTxtBox = arrNumbers.length;
	    loadImages();
        processImages(1);
	    });

	var globalCount = 1;
	var imgNumForProcess = 0;
	var ddlSelectedVal = "";
	function processImages(val) {
        if (val == parseInt(totalCountFromTxtBox) + 1) {
            globalCount = null;
            imgNumForProcess = 0
            return false;
        }
        var xhr = new XMLHttpRequest();
        var xhr2 = new XMLHttpRequest();
        var done = $.Deferred();
        var dtwo = $.Deferred();

        //xhr.open('GET', 'ScreenShots/' + ddlSelectedVal + '_Old_Images/' + 'screenShot' + arrNumbers[imgNumForProcess] + '.jpg', true);
        xhr.open('GET', 'ScreenShots/' + 'Mobile_View_Before_Migration/' + 'screenShot' + arrNumbers[imgNumForProcess] + '.jpg', true);
        xhr.responseType = 'blob';
        xhr.onload = function (e) {
            done.resolve(this.response);
        };
        xhr.send();

        //xhr2.open('GET', 'ScreenShots/' + ddlSelectedVal + '_New_Images/' + 'screenShot' + arrNumbers[imgNumForProcess] + '.jpg', true);
        xhr2.open('GET', 'ScreenShots/' + 'Mobile_View_Post_Migration/' + 'screenShot' + arrNumbers[imgNumForProcess] + '.jpg', true);
        xhr2.responseType = 'blob';
        xhr2.onload = function (e) {
            dtwo.resolve(this.response);
        };
        xhr2.send();

        $.when(done, dtwo).done(function (file, file1) {
            globalCount = val;
            resembleControl = resemble(file).compareTo(file1).onComplete(onComplete);
        });
        imgNumForProcess++;
    }
    
    function loadImages() {
        ddlSelectedVal = $('#ddlCountry').find(':selected').text();
        $('#mainDiv').html('');
        var imgNum = 0;
        for (var i = 1; i <= totalCountFromTxtBox; i++) {
            $('#mainDiv').append('<table style="width:100%"> <tr><th style="font-size: x-large;text-decoration: underline;">Pre-migration: ' + 'screenShot' + arrNumbers[imgNum] + '</th><th style="font-size: x-large;text-decoration: underline;">Post-migration: ' + 'screenShot' + arrNumbers[imgNum] + '</th></tr><tr>'
                //+ '<td><div id="dropzone_a' + i + '" class="small-drop-zone"><img src="ScreenShots/' + ddlSelectedVal + '_Old_Images/' + 'screenShot' + arrNumbers[imgNum] + '.jpg"/></div></td>'
                + '<td><div id="dropzone_a' + i + '" class="small-drop-zone"><img src="ScreenShots/' + 'Mobile_View_Before_Migration/' + 'screenShot' + arrNumbers[imgNum] + '.jpg"/></div></td>'
                //+ '<td><div id="dropzone_b' + i + '" class="small-drop-zone"><img src="ScreenShots/' + ddlSelectedVal + '_New_Images/' + 'screenShot' + arrNumbers[imgNum] + '.jpg"/></div></td></tr></table></br></br>')
                + '<td><div id="dropzone_b' + i + '" class="small-drop-zone"><img src="ScreenShots/' + 'Mobile_View_Post_Migration/' + 'screenShot' + arrNumbers[imgNum] + '.jpg"/></div></td></tr></table></br></br>')
            $('#mainDiv').append('<h3 style="left: 30%;padding-left: 20%;text-decoration: underline;">Result Image: ' + 'screenShot' + arrNumbers[imgNum] + '</h3><div style="left: 7%;" id="image-diff' + i + '" class="small-drop-zone"></div></br>')
            $('#mainDiv').append('<div id="resultDiv' + i + '"><div class="btn-group buttons" style="display:none;font-size: 15px;">'
             + ' <div id="diff-results' + i + '" style="display:none;">  <p><strong>The second image is <span id="mismatch' + i + '">'
             + ' </span>% different compared to the first.<span id="differentdimensions' + i + '" style="display:none;">And they have different dimensions.</span></strong></p></div>'
             + '<p id="thesame' + i + '" style="display:none;"><strong>These images are the same!</strong></p></div></div>'
             + '<hr class="bigHr"></br>')
            imgNum++;
			
			if(i == totalCountFromTxtBox){
				$('#mainDiv').append('<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>');
			}
        }
    };
});
